
import React from "react";
import { useLocation } from "react-router-dom";

function LandingPage() {
  const location = useLocation();
  const { username } = location.state || { username: "Guest" };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome, {username}!</h1>
      <p>Thank you for logging in.</p>
    </div>
  );
}

export default LandingPage;
